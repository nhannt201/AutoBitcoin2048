﻿
Public Class Form1

    Dim a As String = "1"


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        wb.Navigate("http://bitcoin2048.com/")
    End Sub




    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try
            '   Dim a As String = "1"

            If a = "1" Then
                SendKeys.Send("{UP}")
                a = a + 1
            ElseIf a = "2" Then
                SendKeys.Send("{LEFT}")
                a = a + 1
            ElseIf a = "3" Then
                SendKeys.Send("{DOWN}")
                a = a + 1
            ElseIf a = "4" Then
                SendKeys.Send("{RIGHT}")
                a = "1"
            End If
            '  Label2.Text = Label2.Text + 1
        Catch

        End Try
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        '  wb.Document.GetElementById("retry-button").InvokeMember("Click")
        '  wb.Document.GetElementById("keep-playing-button").InvokeMember("Click")
        '  wb.Document.GetElementById("continue-button").InvokeMember("Click")
        Try
            wb.StringByEvaluatingJavaScriptFromString("document.GetAttribute('retry-button').click()")
            wb.StringByEvaluatingJavaScriptFromString("document.Document.GetElementsByTagName('a').click()")
            wb.StringByEvaluatingJavaScriptFromString("document.GetAttribute('continue-button').click()")



            '  SendKeys.Send("{ENTER}")
        Catch

        End Try
        '  SendKeys.Send("{F5}")
    End Sub




    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        '   Private Sub Button1_Click(sender As Object, e As EventArgs)
        Timer1.Interval = TextBox1.Text
        '    Timer2.Interval = TextBox2.Text
        Timer1.Start()
        Timer2.Start()
        Button2.Enabled = True

        Button1.Enabled = False

        '  End Sub
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click

        '  Private Sub Button2_Click(sender As Object, e As EventArgs)
        Timer1.Stop()
        Timer2.Stop()
        Button1.Enabled = True
        Button2.Enabled = False
        ' End Sub
    End Sub



    Private Sub wb_KeyDown(sender As Object, e As KeyEventArgs) Handles wb.KeyDown
        If e.KeyCode = Keys.F1 Then
            Timer1.Start()
            Timer2.Start()

        End If
        If e.KeyCode = Keys.F2 Then
            Timer1.Stop()
            Timer2.Stop()

        End If
    End Sub
End Class
