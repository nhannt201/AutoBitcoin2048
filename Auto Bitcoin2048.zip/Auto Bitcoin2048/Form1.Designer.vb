﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.wb = New WebKit.WebKitBrowser()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox111 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'wb
        '
        Me.wb.BackColor = System.Drawing.Color.White
        Me.wb.Location = New System.Drawing.Point(12, 12)
        Me.wb.Name = "wb"
        Me.wb.Size = New System.Drawing.Size(1259, 650)
        Me.wb.TabIndex = 0
        Me.wb.Url = Nothing
        '
        'Timer1
        '
        Me.Timer1.Interval = 400
        '
        'Timer2
        '
        Me.Timer2.Interval = 2000
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(781, 511)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(134, 42)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "Dừng tự chơi (F2)"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(208, 511)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(134, 42)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Tự chơi 2048 (F1)"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox111
        '
        Me.TextBox111.Location = New System.Drawing.Point(337, 621)
        Me.TextBox111.Multiline = True
        Me.TextBox111.Name = "TextBox111"
        Me.TextBox111.Size = New System.Drawing.Size(416, 20)
        Me.TextBox111.TabIndex = 9
        Me.TextBox111.Text = "1F6fss84gc9c1sNJ8sD4TrdusFrQpyYi1i"
        Me.TextBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(561, 595)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(86, 20)
        Me.TextBox1.TabIndex = 15
        Me.TextBox1.Text = "400"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(496, 598)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Thời gian :"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1283, 674)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox111)
        Me.Controls.Add(Me.wb)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Auto Bitcoin 2048"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents wb As WebKit.WebKitBrowser
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox111 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
End Class
